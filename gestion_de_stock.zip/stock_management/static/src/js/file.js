odoo.define("construction.projects", function(require) {
    'use strict';

    var rpc = require('web.rpc');
    console.log("---------------------");
    console.log(rpc);
    console.log("---------------------");

});